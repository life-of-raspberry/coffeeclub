import os
os.system("sudo reboot")
