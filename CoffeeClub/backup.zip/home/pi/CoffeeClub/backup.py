from send_email import send_email

send_email('backup','/home/pi/CoffeeClub.tar')
